﻿using UnityEngine;

public class FireWeapon : MonoBehaviour {
    public Rigidbody weapon;
    public Transform[] firePoints;
    public string weaponType;
    public float launchSpeed = 30f;
    public float reloadTime = 3f;

	private int playerNum;
    private string fireShellButton;
    private bool coolDown = true;
    private float startTime;

	void Start () {
        playerNum = transform.parent.GetComponent<CreateVehicle>().playerNum;
        if (playerNum == GlobalVars.Keyboard) playerNum = 0;
        fireShellButton = weaponType + playerNum;
	}
	
	void Update () {       
        if (Input.GetButton(fireShellButton) && !coolDown) {
            fire();
            coolDown = true;
            startTime = Time.time;
        }
        else if (coolDown) {
            if (Time.time - startTime > reloadTime) {
                coolDown = false;
            }
        }
	}

    private void fire() {
		for (int i = 0; i < firePoints.Length; i++) {
			Rigidbody weaponInstance = Instantiate (weapon, firePoints[i].position, firePoints[i].rotation) as Rigidbody;
			weaponInstance.velocity = (launchSpeed * firePoints[i].forward * Time.deltaTime);
		}
    }

}
