﻿using UnityEngine;
using System.Collections;

public class BomberWeapons : MonoBehaviour {
    public LayerMask playerLayer;
    public ParticleSystem explosion;
    public float explosionRadius = 10f;

    private bool collision = false;

    void Start () {
	
	}

    void OnCollisionEnter(Collision col) {
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius, playerLayer);
        for (int i = 0; i < colliders.Length; i++) {
            Rigidbody obj = colliders[i].GetComponent<Rigidbody>();
            Destroy(obj.gameObject);
        }

        explosion.transform.parent = null;
        explosion.Play();

        Destroy(explosion.gameObject, explosion.duration);
        Destroy(gameObject);
    }

    void Update() {

    }
	
}
