﻿using UnityEngine;

public class BomberCollision : MonoBehaviour {
    public LayerMask playerLayer;
    public ParticleSystem explosion;
    public float explosionRadius = 10f;

    private bool collision = false;

    void Start () {
	
	}

    void OnCollisionEnter(Collision col) {
        if (col.gameObject.layer != gameObject.layer) {
            Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius, playerLayer);
            for (int i = 0; i < colliders.Length; i++) {
                Rigidbody obj = colliders[i].GetComponent<Rigidbody>();
                Destroy(obj.gameObject);
            }

            explosion.transform.parent = null;
            explosion.Play();

            Destroy(explosion.gameObject, explosion.duration);
            Destroy(gameObject);
        }
    }
}
