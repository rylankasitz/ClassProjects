﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerEnter : MonoBehaviour {
    public int playerNum;
    public Image logo;
    public Text text;

    private string enterGameString;
    private string enterGameStringK;
    private string startString;
    private string mapName;
    private bool entered = false;
    

	void Start () {
        enterGameString = "EnterGame" + playerNum;
        enterGameStringK = "EnterGame0";
        startString = "Start";
        mapName = "TestMap";
    }
	
	void Update () {
		if(Input.GetButtonDown(enterGameString) && !entered)
        {
            Set();
            
        }
        else if (Input.GetButtonDown(enterGameStringK) && GlobalVars.Keyboard == -1  && !entered && playerNum == GlobalVars.PlayerAmount + 1)
        {
            Set();      
            GlobalVars.Keyboard = playerNum;
            print(playerNum);
        }
        if(Input.GetButtonDown(startString))
        {
            SceneManager.LoadScene(mapName);
        }
	}

    void Set()
    {
        logo.gameObject.SetActive(true);
        text.gameObject.SetActive(false);
        GlobalVars.PlayerAmount++;
        entered = true;
    }
}
