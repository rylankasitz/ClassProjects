﻿using UnityEngine;

public class Explosion : MonoBehaviour {
    public LayerMask tankLayer;
    public ParticleSystem explosion;
    public float maxDamage = 100f;
    public float maxLifetime = 2f;
    public float explosionForce = 1000f;
    public float explosionRadius = 5f;

    private bool healthCalc = false;

	void Start () {
        Destroy(gameObject, maxLifetime);
	}

    private void OnTriggerEnter(Collider col) {
        Collider[] colliders = Physics.OverlapSphere(transform.position, explosionRadius, tankLayer);

        for(int i = 0; i < colliders.Length; i++) {
            Rigidbody shell = colliders[i].GetComponent<Rigidbody>();
            if (!shell)
                continue;

            shell.AddExplosionForce(explosionForce, transform.position, explosionRadius);
            Health health = shell.GetComponent<Health>();
            if (!health)
                continue;

            if (!healthCalc) {
                float damage = calculateDamage(shell.position);
                health.currentHealth -= damage;
                healthCalc = true;
            }
        }

        explosion.transform.parent = null;
        explosion.Play();

        Destroy(explosion.gameObject, explosion.duration);
        Destroy(gameObject);
    }

    private float calculateDamage(Vector3 shellPos) {
        Vector3 explosionTankVector = shellPos - transform.position;
        float explosionDistance = explosionTankVector.magnitude;
        float damageFactor = (explosionRadius - explosionDistance) / explosionRadius;
        float damage = Mathf.Max(0f, damageFactor * maxDamage);

        return damage;
    }
}
