﻿using UnityEngine;

public class BomberEject : MonoBehaviour {
    public Transform ejectPoint;
    public Transform ejectHatch;
    public GameObject cameraObj;
    public Rigidbody tank;
    public float planeLifeTime = 20;

	private int playerNum;
    private Rigidbody bomberRid;
    private string ejectButton;
    private bool spawnedTank = false;
    

    void Start () {
        playerNum = transform.parent.GetComponent<CreateVehicle>().playerNum;
        if (playerNum == GlobalVars.Keyboard) playerNum = 0;
        ejectButton = "Eject" + playerNum;
        bomberRid = GetComponent<Rigidbody>();  
    }

	void FixedUpdate () {
        if (Input.GetButton(ejectButton) && !spawnedTank) {
            eject();
			Destroy(gameObject, planeLifeTime);
        }
    }

    private void eject() {
        // Rotate hatch
        Quaternion hatchRot = Quaternion.Euler(45, 180, 0f);
        Vector3 hatchPos = new Vector3(0f, 0.129f, -0.91f);
        ejectHatch.localRotation = hatchRot;
        ejectHatch.localPosition = hatchPos;

        // Disable interactive scripts and input
		gameObject.GetComponent<BomberMovement>().userInput = false;
        Destroy(gameObject.GetComponent<FireWeapon>());
        Destroy(gameObject.GetComponent<FireWeapon>());

        // Freeze plane position
        bomberRid.constraints = RigidbodyConstraints.FreezeRotation | RigidbodyConstraints.FreezePositionY;

        Rigidbody tankClone = transform.parent.GetComponent<CreateVehicle>().setVehicle(tank);
        tankClone.transform.position = ejectPoint.position;
        tankClone.transform.rotation = ejectPoint.rotation;
        tankClone.velocity = bomberRid.velocity;
      
        spawnedTank = true;
    }
} 
