﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class BomberMovement : MonoBehaviour {
    public float currentSpeed = 4;
    public float maxSpeed = 10;
	public float minSpeed = 1;
    public float acceleration = 1;
    public float rollSpeed = 3;
    public float pitchSpeed = 2;
	public bool userInput = true;
	public Slider speedSlider;

	private int playerNum;
    private Rigidbody planeBody;
    private string pitchAxisName;
    private string rollAxisName;
    private string speedButton;
    private float pitchInputValue = 0f;
    private float rollInputValue = 0f;
    private float speedInputValue = 0f;

    void Start() {
        playerNum = transform.parent.GetComponent<CreateVehicle>().playerNum;
        if (playerNum == GlobalVars.Keyboard) playerNum = 0;
        planeBody = GetComponent<Rigidbody>();
        speedButton = "EnginePower" + playerNum;
		pitchAxisName = "Pitch" + playerNum;
		rollAxisName = "Roll" + playerNum;
        speedSlider = transform.parent.GetComponentInChildren<Slider>();
    }

    void Update() {
		if (userInput) {
			speedSlider.value = (currentSpeed/maxSpeed)*100;
			pitchInputValue = Input.GetAxis (pitchAxisName);
			rollInputValue = Input.GetAxis (rollAxisName);
			speedInputValue = Input.GetAxisRaw (speedButton);
		}
		updateSpeed ();
    }

    private void FixedUpdate() {
        move();
        turn();
    }

	private void updateSpeed(){
		if (currentSpeed < maxSpeed && currentSpeed > minSpeed) {
			currentSpeed += acceleration * Time.deltaTime * speedInputValue;
		}
		else {
			if (currentSpeed >= maxSpeed) { currentSpeed = maxSpeed - .1f; }
			else if(currentSpeed <= minSpeed) { currentSpeed = minSpeed + .1f; }
		}
	}

    private void move() {
        Vector3 movement = transform.forward * currentSpeed * Time.deltaTime;
        planeBody.MovePosition(planeBody.position + movement);
    }

    private void turn() {
		float rollDeg = rollSpeed * -rollInputValue * Time.deltaTime; 
		float pitchDeg = pitchSpeed * pitchInputValue * Time.deltaTime;
		transform.RotateAround(transform.position, transform.right, pitchDeg);
        transform.RotateAround(transform.position, transform.forward, rollDeg);
    }
}
