﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Drops : MonoBehaviour
{
    public float rotationSpeed = 10;
    public Transform spawnPosition;
    public Rigidbody drop;
    public GameObject[] spawns;

    void Start()
    {
    }

    void Update()
    {
        transform.Rotate(new Vector3(0, rotationSpeed, 0));
    }

    private void OnTriggerEnter(Collider col)
    {
        col.transform.parent.transform.position = spawnPosition.position;
        Destroy(col.gameObject);
        col.transform.parent.GetComponent<CreateVehicle>().setVehicle(drop);

        Destroy(gameObject);
        int rand = Random.Range(0, spawns.Length - 1);
        GameObject dropInstance = Instantiate(spawns[rand]) as GameObject;
        dropInstance.transform.parent = transform.parent;
    }
}