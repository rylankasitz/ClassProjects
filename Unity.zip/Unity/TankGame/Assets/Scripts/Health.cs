﻿using UnityEngine;
using UnityEngine.UI;

public class Health : MonoBehaviour {
	public float currentHealth = 100;
    public float maxHealth = 100;
    public Slider healthSlider;

    private float healthFactor;

	private void Awake() {
        healthFactor = maxHealth / 100;
	}

	void Update () {
		healthSlider.value = currentHealth / healthFactor;
    }
		
	private void onDeath(){
		
	}
}
