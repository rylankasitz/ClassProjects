﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GenerateDrops : MonoBehaviour {

    public GameObject[] objects;
    private Transform[] children;

	void Start () {
        children = transform.GetComponentsInChildren<Transform>();
        SpawnObjs();
    }

	void Update () {
		
	}

    private void SpawnObjs()
    {
        for(int i = 0; i < children.Length; i++)
        {
            int rand = Random.Range(0, objects.Length - 1); 
            GameObject dropInstance = Instantiate(objects[rand]) as GameObject;
            dropInstance.transform.parent = children[i];
            dropInstance.transform.localPosition = Vector3.zero;
        }       
    }
}
