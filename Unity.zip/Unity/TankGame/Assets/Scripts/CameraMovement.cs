﻿using UnityEngine;

public class CameraMovement : MonoBehaviour {
	public Transform obj;
	public Transform[] setAngles;
    private Camera camera;
    public float scaleFactor = 10;

	void Start () {
        camera = GetComponentInChildren<Camera>();
	}

    void FixedUpdate() {
        if (obj != null) {
            setPosition();
        }
    }

	public void setPosition(){
		transform.position = obj.position;
		Quaternion turnRotation = Quaternion.Euler(setAngles[0].eulerAngles.x, setAngles[1].eulerAngles.y, setAngles[2].eulerAngles.z);
		transform.rotation = turnRotation;
        Vector3 camPos = new Vector3(0, (obj.localScale.x * scaleFactor)/3, -obj.localScale.x*scaleFactor);
        camera.transform.localPosition = camPos;
	}
}
