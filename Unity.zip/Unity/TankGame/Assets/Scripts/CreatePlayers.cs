﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreatePlayers : MonoBehaviour {
    public GameObject player;

    private Transform[] spawnpoints;
    private int playerAmount;

    void Start () {
        print(GlobalVars.PlayerAmount);
        spawnpoints = transform.GetComponentsInChildren<Transform>();
        playerAmount = GlobalVars.PlayerAmount;
        for(int i = 0; i < playerAmount; i++)
        {
            spawnPlayer(i + 1);
        }      
    }

    public void spawnPlayer(int playerNum)
    {
        int rand = Random.Range((playerNum - 1)*2, (playerNum - 1)*2 + 2);
        GameObject playerInst = Instantiate(player) as GameObject;
        playerInst.transform.position = spawnpoints[rand].position;
        playerInst.GetComponent<CreateVehicle>().playerNum = playerNum;
    }
}
