﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class GlobalVars
{
    private static int playerAmount;
    private static int keyboard = -1;
    public static int PlayerAmount
    {
        get
        {
            return playerAmount;
        }
        set
        {
            playerAmount = value;
        }
    }

    public static int Keyboard
    {
        get
        {
            return keyboard;
        }
        set
        {
            keyboard = value;
        }
    }
}


