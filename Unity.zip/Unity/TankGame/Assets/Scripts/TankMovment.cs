﻿using UnityEngine;
using System.Collections;

public class TankMovment : MonoBehaviour {
	public float maxSpeed = 12f;
    public float turnSpeed = 180f;
	private int playerNum = 1;
    public float flipPower = 3;
    public float turnFlipPower = 25;

	private Rigidbody Rigidbody;
    private string movementAxisName;
    private string turnAxisName;
    private string flipButton;
    private float movementInputValue;
    private float turnInputValue;

    private void Awake()
    {
        Rigidbody = GetComponent<Rigidbody>();
    }

    private void OnEnable()
    {
        movementInputValue = 0f;
        turnInputValue = 0f;
    }

	void Start ()
    {
		playerNum = transform.parent.GetComponent<CreateVehicle>().playerNum;
        if (playerNum == GlobalVars.Keyboard) playerNum = 0;
        movementAxisName = "Foward" + playerNum;
        turnAxisName = "Turn" + playerNum;
        flipButton = "Flip" + playerNum;
	}

	void Update ()
    {
        
      
    }
		
    private void FixedUpdate()
    {
        
        if ((transform.localEulerAngles.z < 45 || transform.localEulerAngles.z > 315)) {
            movementInputValue = Input.GetAxis(movementAxisName);
            turnInputValue = Input.GetAxis(turnAxisName);
            Move();
            Turn();
        }
        else if(Input.GetButtonDown(flipButton))
        {
            movementInputValue = 0;
            turnInputValue = 0;
            Flip();
        }
        else
        {
            movementInputValue = 0;
            turnInputValue = 0;
        }
    }
		
    private void Move()
    {
		Vector3 movement = transform.forward * movementInputValue * maxSpeed * Time.deltaTime;
        Rigidbody.MovePosition(Rigidbody.position + movement);
    }

    private void Turn()
    {
        float turnDeg = turnInputValue * turnSpeed * Time.deltaTime;
        Quaternion turnRotation = Quaternion.Euler(0f, turnDeg, 0f);
        Rigidbody.MoveRotation(Rigidbody.rotation * turnRotation);
    }
    
    private void Flip()
    {
        Rigidbody.AddForce(new Vector3(0, flipPower, 0));
        Quaternion turn = Quaternion.Euler(0f, 180, 0f);
        Rigidbody.angularVelocity = transform.forward * turnFlipPower;
    }
}
