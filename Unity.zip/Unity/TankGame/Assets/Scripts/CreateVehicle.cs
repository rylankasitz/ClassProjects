﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CreateVehicle : MonoBehaviour {
    public Rigidbody currentVehicle;
    public int playerNum = 1;

    private CameraMovement cameraRig;

	void Start () {
        cameraRig = transform.GetComponentInChildren<CameraMovement>();
        setCameraSize();
        setVehicle(currentVehicle);
    }	

    public Rigidbody setVehicle(Rigidbody v)
    {
        Rigidbody vehicle = Instantiate(v) as Rigidbody;
        vehicle.transform.parent = transform;      
        cameraRig.obj = vehicle.transform;
        cameraRig.setAngles[0] = vehicle.transform;
        cameraRig.setAngles[1] = vehicle.transform;
        cameraRig.setAngles[2] = vehicle.transform;

        if(vehicle.GetComponent<Health>() != null)
        {
           vehicle.transform.GetComponent<Health>().healthSlider =  vehicle.transform.parent.GetComponentsInChildren<Slider>()[1];
        }
        return vehicle;
    }

    private void setCameraSize()
    {
        Camera camera = cameraRig.GetComponentInChildren<Camera>();
        if(GlobalVars.PlayerAmount <= 2)
        {
            if(playerNum == 1)
            {
                camera.rect = new Rect(0, .5f, 1, .5f);
            }
            else if(playerNum == 2)
            {
                camera.rect = new Rect(0, 0, 1, .5f);
            }
        }
        else
        {
            if (playerNum == 1)
            {
                camera.rect = new Rect(0, .5f, .5f, .5f);
            }
            else if (playerNum == 2)
            {
                camera.rect = new Rect(.5f, .5f, .5f, .5f);
            }
            else if (playerNum == 3)
            {
                camera.rect = new Rect(0, 0, .5f, .5f);
            }
            else if (playerNum == 4)
            {
                camera.rect = new Rect(.5f, 0, .5f, .5f);
            } 
        }
          
    }
}

